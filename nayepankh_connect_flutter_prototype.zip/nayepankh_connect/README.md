# NayePankh Connect — Flutter Prototype

Companion prototype for the NayePankh Foundation Mobile App Proposal
(Internship Option 2). This is a **frontend-only, no-backend** Flutter app:
all data lives in `lib/data/mock_data.dart` as an in-memory store, so the
app is fully interactive without Firebase, AWS, or any network calls.

## Screens included

| Screen | File | What it shows |
|---|---|---|
| Splash | `lib/screens/splash_screen.dart` | Brand intro + impact teaser |
| Login (mock OTP) | `lib/screens/login_screen.dart` | Phone number → OTP → continue (or guest) |
| Home | `lib/screens/home_screen.dart` | Total impact counter, upcoming drives preview |
| Drives | `lib/screens/drives_screen.dart` | Full drive list with category filter chips |
| Drive detail | `lib/screens/drive_detail_screen.dart` | Drive info, RSVP, jump to Donate |
| Donate | `lib/screens/donate_screen.dart` | Amount picker, mock payment, 80G receipt sheet |
| Impact feed | `lib/screens/impact_screen.dart` | Past drive results with people-helped counts |
| Profile | `lib/screens/profile_screen.dart` | Donation history, volunteer hours, settings |

Navigation shell with the bottom tab bar lives in `lib/screens/home_shell.dart`.

## How to run

1. Make sure the Flutter SDK is installed (`flutter --version`).
2. From this folder:
   ```bash
   flutter pub get
   flutter run
   ```
3. To preview in a browser instead of a device/emulator:
   ```bash
   flutter run -d chrome
   ```

## What's mocked vs. what's real architecture

- **Real**: navigation flow, state management pattern (`ChangeNotifier`),
  widget structure, theming — all of this maps directly onto the Flutter +
  Riverpod/BLoC + Firebase stack recommended in the report.
- **Mocked**: authentication (no real OTP is sent), payments (no real
  gateway call), and all drive/donation/impact data (hardcoded in
  `mock_data.dart` instead of Firestore).

To move this toward production, the only file that would need to change
to talk to a real backend is `lib/data/mock_data.dart` — swap its
in-memory lists for Firestore queries and the screens above don't need
to change.

## Folder structure

```
lib/
  main.dart
  theme/app_theme.dart        # colors, text styles, component theming
  models/models.dart          # Drive, ImpactPost, DonationRecord, DriveCategory
  data/mock_data.dart         # in-memory mock data layer (stand-in for Firestore)
  widgets/
    drive_card.dart
    impact_post_card.dart
  screens/
    splash_screen.dart
    login_screen.dart
    home_shell.dart
    home_screen.dart
    drives_screen.dart
    drive_detail_screen.dart
    donate_screen.dart
    impact_screen.dart
    profile_screen.dart
```
