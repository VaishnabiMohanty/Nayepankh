import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';

class DriveCard extends StatelessWidget {
  final Drive drive;
  final VoidCallback onTap;
  final VoidCallback onRsvp;

  const DriveCard({
    super.key,
    required this.drive,
    required this.onTap,
    required this.onRsvp,
  });

  Color _categoryColor() {
    switch (drive.category) {
      case DriveCategory.food:
        return const Color(0xFFE8754A);
      case DriveCategory.hygiene:
        return const Color(0xFF6B8FB5);
      case DriveCategory.clothing:
        return const Color(0xFF7A8B5C);
      case DriveCategory.education:
        return const Color(0xFFB07CC4);
    }
  }

  IconData _categoryIcon() {
    switch (drive.category) {
      case DriveCategory.food:
        return Icons.restaurant_outlined;
      case DriveCategory.hygiene:
        return Icons.health_and_safety_outlined;
      case DriveCategory.clothing:
        return Icons.checkroom_outlined;
      case DriveCategory.education:
        return Icons.menu_book_outlined;
    }
  }

  @override
  Widget build(BuildContext context) {
    final progress = (drive.rsvpCount / drive.targetCount).clamp(0.0, 1.0);
    final color = _categoryColor();

    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: color.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(_categoryIcon(), color: color, size: 22),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          drive.title,
                          style: Theme.of(context).textTheme.titleMedium,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 2),
                        Text(
                          '${drive.city} · ${DateFormat('d MMM').format(drive.date)}',
                          style: Theme.of(context).textTheme.bodyMedium,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              ClipRRect(
                borderRadius: BorderRadius.circular(6),
                child: LinearProgressIndicator(
                  value: progress,
                  minHeight: 6,
                  backgroundColor: AppColors.border,
                  valueColor: AlwaysStoppedAnimation(color),
                ),
              ),
              const SizedBox(height: 6),
              Row(
                children: [
                  Text(
                    '${drive.rsvpCount} of ${drive.targetCount} volunteers',
                    style: Theme.of(context)
                        .textTheme
                        .bodyMedium
                        ?.copyWith(fontSize: 12.5),
                  ),
                  const Spacer(),
                  SizedBox(
                    height: 32,
                    child: OutlinedButton(
                      onPressed: onRsvp,
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(horizontal: 14),
                        side: BorderSide(
                          color: drive.userRsvped ? AppColors.success : AppColors.navy,
                        ),
                        foregroundColor:
                            drive.userRsvped ? AppColors.success : AppColors.navy,
                        textStyle: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600),
                      ),
                      child: Text(drive.userRsvped ? "You're in ✓" : 'RSVP'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
