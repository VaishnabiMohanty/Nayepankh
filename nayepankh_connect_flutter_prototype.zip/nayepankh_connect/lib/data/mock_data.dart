import 'package:flutter/foundation.dart';
import '../models/models.dart';

/// Mock in-memory data layer.
///
/// This stands in for what would be Cloud Firestore in production. Keeping
/// it isolated here means swapping in real Firestore calls later only
/// touches this file — screens consume [AppData] and don't know the
/// difference.
class AppData extends ChangeNotifier {
  AppData._internal();
  static final AppData instance = AppData._internal();

  String donorName = 'Vaishnabi Patra';
  int volunteerHours = 18;
  int totalPeopleHelped = 204600;

  final List<Drive> _drives = [
    Drive(
      id: 'd1',
      title: 'Winter Ration Kit Distribution',
      city: 'Kanpur',
      date: DateTime.now().add(const Duration(days: 3)),
      category: DriveCategory.food,
      targetCount: 200,
      rsvpCount: 34,
      imageAsset: 'assets/images/food_drive.png',
      description:
          'Distributing monthly ration kits (rice, dal, oil, spices) to underprivileged families ahead of winter. Volunteers help with packing, transport, and door-to-door delivery.',
    ),
    Drive(
      id: 'd2',
      title: 'Sanitary Hygiene Awareness Camp',
      city: 'Ghaziabad',
      date: DateTime.now().add(const Duration(days: 7)),
      category: DriveCategory.hygiene,
      targetCount: 150,
      rsvpCount: 21,
      imageAsset: 'assets/images/hygiene_drive.png',
      description:
          'A awareness session for young women on menstrual hygiene, followed by free sanitary napkin distribution. Volunteers assist with session logistics and kit handouts.',
    ),
    Drive(
      id: 'd3',
      title: 'Warm Clothing Drive',
      city: 'Kanpur',
      date: DateTime.now().add(const Duration(days: 12)),
      category: DriveCategory.clothing,
      targetCount: 300,
      rsvpCount: 9,
      imageAsset: 'assets/images/clothing_drive.png',
      description:
          'Collecting and distributing warm clothes to families and stray animals ahead of the cold season. Sorting happens the evening before distribution day.',
    ),
    Drive(
      id: 'd4',
      title: 'Weekend Learning Circle',
      city: 'Lucknow',
      date: DateTime.now().add(const Duration(days: 16)),
      category: DriveCategory.education,
      targetCount: 60,
      rsvpCount: 14,
      imageAsset: 'assets/images/education_drive.png',
      description:
          'Free weekend tutoring sessions in basic literacy and numeracy for children from underprivileged households. No prior teaching experience required.',
    ),
  ];

  final List<ImpactPost> _impactPosts = [
    ImpactPost(
      id: 'i1',
      driveTitle: 'Monsoon Ration Drive',
      city: 'Kanpur',
      date: DateTime.now().subtract(const Duration(days: 5)),
      summary:
          '180 ration kits delivered across 4 localities with the help of 22 volunteers. Thank you to everyone who donated this month!',
      peopleHelped: 720,
      imageAsset: 'assets/images/impact_1.png',
    ),
    ImpactPost(
      id: 'i2',
      driveTitle: 'Hygiene Kit Distribution',
      city: 'Ghaziabad',
      date: DateTime.now().subtract(const Duration(days: 14)),
      summary:
          'Distributed sanitary kits to 140 young women and ran an awareness session at a government school.',
      peopleHelped: 140,
      imageAsset: 'assets/images/impact_2.png',
    ),
    ImpactPost(
      id: 'i3',
      driveTitle: 'Stray Animal Feeding Drive',
      city: 'Kanpur',
      date: DateTime.now().subtract(const Duration(days: 21)),
      summary:
          'Fed over 90 stray animals across the city and provided basic first-aid for 6 injured strays in partnership with a local vet.',
      peopleHelped: 90,
      imageAsset: 'assets/images/impact_3.png',
    ),
  ];

  final List<DonationRecord> _donations = [
    DonationRecord(
      id: 'r1',
      amount: 500,
      date: DateTime.now().subtract(const Duration(days: 40)),
      driveTitle: 'Monsoon Ration Drive',
      receiptNo: 'NPF-2026-00214',
    ),
  ];

  List<Drive> get drives => List.unmodifiable(_drives);
  List<ImpactPost> get impactPosts => List.unmodifiable(_impactPosts);
  List<DonationRecord> get donations => List.unmodifiable(_donations);

  void toggleRsvp(String driveId) {
    final idx = _drives.indexWhere((d) => d.id == driveId);
    if (idx == -1) return;
    final drive = _drives[idx];
    final newRsvp = !drive.userRsvped;
    _drives[idx] = drive.copyWith(
      userRsvped: newRsvp,
      rsvpCount: drive.rsvpCount + (newRsvp ? 1 : -1),
    );
    if (newRsvp) volunteerHours += 0; // hours only added after attendance is marked
    notifyListeners();
  }

  void addDonation(double amount, String driveTitle) {
    final receiptNo =
        'NPF-2026-${(1000 + _donations.length).toString().padLeft(5, '0')}';
    _donations.insert(
      0,
      DonationRecord(
        id: 'r${_donations.length + 1}',
        amount: amount,
        date: DateTime.now(),
        driveTitle: driveTitle,
        receiptNo: receiptNo,
      ),
    );
    totalPeopleHelped += (amount / 50).round();
    notifyListeners();
  }
}
