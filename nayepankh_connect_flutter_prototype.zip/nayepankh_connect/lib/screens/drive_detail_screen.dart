import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../data/mock_data.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';
import 'donate_screen.dart';

class DriveDetailScreen extends StatelessWidget {
  final String driveId;
  const DriveDetailScreen({super.key, required this.driveId});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: AppData.instance,
      builder: (context, _) {
        final data = AppData.instance;
        final drive = data.drives.firstWhere((d) => d.id == driveId);
        final progress = (drive.rsvpCount / drive.targetCount).clamp(0.0, 1.0);

        return Scaffold(
          appBar: AppBar(title: Text(drive.title, style: const TextStyle(fontSize: 17))),
          body: SafeArea(
            child: ListView(
              padding: const EdgeInsets.all(20),
              children: [
                AspectRatio(
                  aspectRatio: 16 / 9,
                  child: Container(
                    decoration: BoxDecoration(
                      color: AppColors.navy.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Center(
                      child: Icon(_categoryIcon(drive.category),
                          size: 48, color: AppColors.navy),
                    ),
                  ),
                ),
                const SizedBox(height: 18),
                Row(
                  children: [
                    Icon(Icons.location_on_outlined, size: 18, color: AppColors.textSecondary),
                    const SizedBox(width: 4),
                    Text(drive.city, style: Theme.of(context).textTheme.bodyMedium),
                    const SizedBox(width: 16),
                    Icon(Icons.calendar_today_outlined, size: 16, color: AppColors.textSecondary),
                    const SizedBox(width: 4),
                    Text(DateFormat('EEE, d MMM, yyyy').format(drive.date),
                        style: Theme.of(context).textTheme.bodyMedium),
                  ],
                ),
                const SizedBox(height: 16),
                Text('About this drive', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 6),
                Text(drive.description, style: Theme.of(context).textTheme.bodyLarge),
                const SizedBox(height: 20),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppColors.cream,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Volunteer progress', style: Theme.of(context).textTheme.bodyLarge),
                          Text('${drive.rsvpCount} / ${drive.targetCount}',
                              style: const TextStyle(fontWeight: FontWeight.w600)),
                        ],
                      ),
                      const SizedBox(height: 8),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(6),
                        child: LinearProgressIndicator(
                          value: progress,
                          minHeight: 8,
                          backgroundColor: AppColors.border,
                          valueColor: const AlwaysStoppedAnimation(AppColors.coral),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 24),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => data.toggleRsvp(drive.id),
                        style: OutlinedButton.styleFrom(
                          side: BorderSide(
                              color: drive.userRsvped ? AppColors.success : AppColors.navy),
                          foregroundColor:
                              drive.userRsvped ? AppColors.success : AppColors.navy,
                        ),
                        child: Text(drive.userRsvped ? "You're attending ✓" : 'RSVP to volunteer'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () => Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (_) => DonateScreen(prefillDriveTitle: drive.title),
                          ),
                        ),
                        child: const Text('Donate'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  IconData _categoryIcon(DriveCategory category) {
    switch (category) {
      case DriveCategory.food:
        return Icons.restaurant_outlined;
      case DriveCategory.hygiene:
        return Icons.health_and_safety_outlined;
      case DriveCategory.clothing:
        return Icons.checkroom_outlined;
      case DriveCategory.education:
        return Icons.menu_book_outlined;
    }
  }
}
