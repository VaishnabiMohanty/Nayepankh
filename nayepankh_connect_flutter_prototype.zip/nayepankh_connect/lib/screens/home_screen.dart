import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../data/mock_data.dart';
import '../theme/app_theme.dart';
import '../widgets/drive_card.dart';
import 'drive_detail_screen.dart';

class HomeScreen extends StatelessWidget {
  final VoidCallback onSeeDrives;
  const HomeScreen({super.key, required this.onSeeDrives});

  @override
  Widget build(BuildContext context) {
    final data = AppData.instance;
    final upcoming = data.drives.take(2).toList();
    final numberFmt = NumberFormat.decimalPattern('en_IN');

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Namaste, ${data.donorName.split(' ').first} 👋',
                        style: Theme.of(context).textTheme.titleLarge),
                    const SizedBox(height: 2),
                    Text('Let\'s give some wings today.',
                        style: Theme.of(context).textTheme.bodyMedium),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: AppColors.coralLight,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(Icons.notifications_outlined, color: AppColors.coral),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: AppColors.navy,
              borderRadius: BorderRadius.circular(18),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Total impact so far',
                    style: TextStyle(color: Colors.white70, fontSize: 13)),
                const SizedBox(height: 6),
                Text(
                  numberFmt.format(data.totalPeopleHelped),
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 32,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const Text('people helped', style: TextStyle(color: Colors.white70)),
                const SizedBox(height: 14),
                Row(
                  children: const [
                    _MiniStat(label: 'Food kits', value: '38.2k'),
                    SizedBox(width: 18),
                    _MiniStat(label: 'Hygiene kits', value: '21.4k'),
                    SizedBox(width: 18),
                    _MiniStat(label: 'Volunteers', value: '1,860'),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Upcoming drives', style: Theme.of(context).textTheme.titleMedium),
              TextButton(onPressed: onSeeDrives, child: const Text('See all')),
            ],
          ),
          const SizedBox(height: 8),
          ...upcoming.map(
            (d) => Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: DriveCard(
                drive: d,
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => DriveDetailScreen(driveId: d.id)),
                ),
                onRsvp: () => data.toggleRsvp(d.id),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _MiniStat extends StatelessWidget {
  final String label;
  final String value;
  const _MiniStat({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(value,
              style: const TextStyle(
                  color: Colors.white, fontWeight: FontWeight.w600, fontSize: 15)),
          Text(label, style: const TextStyle(color: Colors.white60, fontSize: 11)),
        ],
      ),
    );
  }
}
