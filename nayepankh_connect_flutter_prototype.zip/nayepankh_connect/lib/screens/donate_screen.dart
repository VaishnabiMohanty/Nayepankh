import 'package:flutter/material.dart';
import '../data/mock_data.dart';
import '../theme/app_theme.dart';

class DonateScreen extends StatefulWidget {
  final String? prefillDriveTitle;
  const DonateScreen({super.key, this.prefillDriveTitle});

  @override
  State<DonateScreen> createState() => _DonateScreenState();
}

class _DonateScreenState extends State<DonateScreen> {
  int? _selectedAmount;
  final _customController = TextEditingController();
  bool _processing = false;

  static const presets = [200, 500, 1000, 2500];

  @override
  Widget build(BuildContext context) {
    final driveLabel = widget.prefillDriveTitle ?? 'General Fund';

    return Scaffold(
      appBar: AppBar(title: const Text('Donate')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppColors.coralLight,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Row(
                children: [
                  const Icon(Icons.favorite, color: AppColors.coral),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'Supporting: $driveLabel',
                      style: const TextStyle(fontWeight: FontWeight.w600, color: AppColors.navy),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 22),
            Text('Choose an amount', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 10),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: presets.map((amt) {
                final selected = _selectedAmount == amt;
                return GestureDetector(
                  onTap: () => setState(() {
                    _selectedAmount = amt;
                    _customController.clear();
                  }),
                  child: Container(
                    width: (MediaQuery.of(context).size.width - 40 - 10) / 2,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: selected ? AppColors.navy : AppColors.surface,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: selected ? AppColors.navy : AppColors.border),
                    ),
                    child: Text(
                      '₹$amt',
                      style: TextStyle(
                        color: selected ? Colors.white : AppColors.textPrimary,
                        fontWeight: FontWeight.w600,
                        fontSize: 16,
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _customController,
              keyboardType: TextInputType.number,
              onChanged: (_) => setState(() => _selectedAmount = null),
              decoration: const InputDecoration(
                prefixText: '₹  ',
                hintText: 'Enter a custom amount',
              ),
            ),
            const SizedBox(height: 24),
            Text('Payment method', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 10),
            _PaymentOption(icon: Icons.qr_code, label: 'UPI', selected: true),
            const SizedBox(height: 8),
            const _PaymentOption(icon: Icons.credit_card, label: 'Card', selected: false),
            const SizedBox(height: 8),
            const _PaymentOption(icon: Icons.account_balance, label: 'Net banking', selected: false),
            const SizedBox(height: 28),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppColors.cream,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  const Icon(Icons.verified_outlined, size: 18, color: AppColors.success),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Eligible for 50% tax exemption under 80G. A receipt is generated automatically.',
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(fontSize: 12.5),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 22),
            ElevatedButton(
              onPressed: _currentAmount() == null || _processing
                  ? null
                  : () => _handleDonate(driveLabel),
              child: _processing
                  ? const SizedBox(
                      height: 18,
                      width: 18,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                    )
                  : Text('Donate ${_currentAmount() != null ? '₹${_currentAmount()}' : ''}'),
            ),
          ],
        ),
      ),
    );
  }

  int? _currentAmount() {
    if (_selectedAmount != null) return _selectedAmount;
    final text = _customController.text.trim();
    if (text.isEmpty) return null;
    return int.tryParse(text);
  }

  Future<void> _handleDonate(String driveLabel) async {
    setState(() => _processing = true);
    await Future.delayed(const Duration(milliseconds: 900)); // simulate gateway round-trip
    final amount = _currentAmount()!.toDouble();
    AppData.instance.addDonation(amount, driveLabel);
    setState(() => _processing = false);
    if (!mounted) return;
    _showReceiptSheet(amount, driveLabel);
  }

  void _showReceiptSheet(double amount, String driveLabel) {
    final receipt = AppData.instance.donations.first;
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) {
        return Container(
          padding: const EdgeInsets.all(24),
          decoration: const BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                width: 64,
                height: 64,
                decoration: const BoxDecoration(color: AppColors.success, shape: BoxShape.circle),
                child: const Icon(Icons.check, color: Colors.white, size: 32),
              ),
              const SizedBox(height: 16),
              Text('Thank you!', style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 4),
              Text(
                'Your ₹${amount.toInt()} donation to $driveLabel was received.',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              const SizedBox(height: 20),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppColors.cream,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.receipt_long_outlined, color: AppColors.navy),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('80G Receipt', style: Theme.of(context).textTheme.bodyLarge),
                          Text(receipt.receiptNo, style: Theme.of(context).textTheme.bodyMedium),
                        ],
                      ),
                    ),
                    TextButton(onPressed: () {}, child: const Text('View')),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                    Navigator.of(context).pop();
                  },
                  child: const Text('Done'),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _PaymentOption extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool selected;
  const _PaymentOption({required this.icon, required this.label, required this.selected});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: selected ? AppColors.navy : AppColors.border, width: selected ? 1.3 : 1),
      ),
      child: Row(
        children: [
          Icon(icon, color: selected ? AppColors.navy : AppColors.textSecondary, size: 20),
          const SizedBox(width: 12),
          Text(label, style: TextStyle(fontWeight: selected ? FontWeight.w600 : FontWeight.w400)),
          const Spacer(),
          if (selected) const Icon(Icons.check_circle, color: AppColors.navy, size: 18),
        ],
      ),
    );
  }
}
