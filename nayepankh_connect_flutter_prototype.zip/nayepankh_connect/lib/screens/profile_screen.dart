import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../data/mock_data.dart';
import '../theme/app_theme.dart';
import 'login_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: AppData.instance,
      builder: (context, _) {
        final data = AppData.instance;
        return SafeArea(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
            children: [
              Row(
                children: [
                  CircleAvatar(
                    radius: 30,
                    backgroundColor: AppColors.navy,
                    child: Text(
                      data.donorName.split(' ').map((n) => n[0]).take(2).join(),
                      style: const TextStyle(
                          color: Colors.white, fontWeight: FontWeight.w600, fontSize: 18),
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(data.donorName, style: Theme.of(context).textTheme.titleMedium),
                        Text('Volunteer & Donor', style: Theme.of(context).textTheme.bodyMedium),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: () {},
                    icon: const Icon(Icons.edit_outlined, color: AppColors.textSecondary),
                  ),
                ],
              ),
              const SizedBox(height: 22),
              Row(
                children: [
                  _StatTile(label: 'Volunteer hours', value: '${data.volunteerHours}'),
                  const SizedBox(width: 12),
                  _StatTile(label: 'Donations made', value: '${data.donations.length}'),
                  const SizedBox(width: 12),
                  const _StatTile(label: 'Certificates', value: '2'),
                ],
              ),
              const SizedBox(height: 24),
              Text('Donation history', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 10),
              if (data.donations.isEmpty)
                Text('No donations yet', style: Theme.of(context).textTheme.bodyMedium)
              else
                ...data.donations.map((r) => Card(
                      margin: const EdgeInsets.only(bottom: 10),
                      child: Padding(
                        padding: const EdgeInsets.all(14),
                        child: Row(
                          children: [
                            Container(
                              width: 38,
                              height: 38,
                              decoration: BoxDecoration(
                                color: AppColors.success.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: const Icon(Icons.receipt_long_outlined,
                                  color: AppColors.success, size: 19),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(r.driveTitle, style: Theme.of(context).textTheme.bodyLarge),
                                  Text(
                                    '${DateFormat('d MMM, yyyy').format(r.date)} · ${r.receiptNo}',
                                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(fontSize: 12),
                                  ),
                                ],
                              ),
                            ),
                            Text(
                              '₹${r.amount.toInt()}',
                              style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15),
                            ),
                          ],
                        ),
                      ),
                    )),
              const SizedBox(height: 14),
              Text('Settings', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 10),
              _SettingsRow(icon: Icons.language_outlined, label: 'App language', trailing: 'English'),
              _SettingsRow(icon: Icons.notifications_outlined, label: 'Notifications', trailing: 'On'),
              _SettingsRow(icon: Icons.help_outline, label: 'Help & support', trailing: ''),
              const SizedBox(height: 8),
              TextButton(
                onPressed: () {
                  Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => const LoginScreen()),
                    (route) => false,
                  );
                },
                child: const Text('Log out', style: TextStyle(color: AppColors.coral)),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _StatTile extends StatelessWidget {
  final String label;
  final String value;
  const _StatTile({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.border),
        ),
        child: Column(
          children: [
            Text(value,
                style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 18, color: AppColors.navy)),
            const SizedBox(height: 2),
            Text(label,
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(fontSize: 11)),
          ],
        ),
      ),
    );
  }
}

class _SettingsRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String trailing;
  const _SettingsRow({required this.icon, required this.label, required this.trailing});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        children: [
          Icon(icon, size: 20, color: AppColors.textSecondary),
          const SizedBox(width: 14),
          Expanded(child: Text(label, style: Theme.of(context).textTheme.bodyLarge)),
          if (trailing.isNotEmpty)
            Text(trailing, style: Theme.of(context).textTheme.bodyMedium),
          const SizedBox(width: 6),
          const Icon(Icons.chevron_right, size: 18, color: AppColors.textSecondary),
        ],
      ),
    );
  }
}
