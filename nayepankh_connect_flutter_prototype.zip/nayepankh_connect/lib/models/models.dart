enum DriveCategory { food, hygiene, clothing, education }

extension DriveCategoryX on DriveCategory {
  String get label {
    switch (this) {
      case DriveCategory.food:
        return 'Food';
      case DriveCategory.hygiene:
        return 'Hygiene';
      case DriveCategory.clothing:
        return 'Clothing';
      case DriveCategory.education:
        return 'Education';
    }
  }
}

class Drive {
  final String id;
  final String title;
  final String city;
  final DateTime date;
  final DriveCategory category;
  final int targetCount;
  final int rsvpCount;
  final String imageAsset;
  final String description;
  final bool userRsvped;

  const Drive({
    required this.id,
    required this.title,
    required this.city,
    required this.date,
    required this.category,
    required this.targetCount,
    required this.rsvpCount,
    required this.imageAsset,
    required this.description,
    this.userRsvped = false,
  });

  Drive copyWith({bool? userRsvped, int? rsvpCount}) {
    return Drive(
      id: id,
      title: title,
      city: city,
      date: date,
      category: category,
      targetCount: targetCount,
      rsvpCount: rsvpCount ?? this.rsvpCount,
      imageAsset: imageAsset,
      description: description,
      userRsvped: userRsvped ?? this.userRsvped,
    );
  }
}

class ImpactPost {
  final String id;
  final String driveTitle;
  final String city;
  final DateTime date;
  final String summary;
  final int peopleHelped;
  final String imageAsset;

  const ImpactPost({
    required this.id,
    required this.driveTitle,
    required this.city,
    required this.date,
    required this.summary,
    required this.peopleHelped,
    required this.imageAsset,
  });
}

class DonationRecord {
  final String id;
  final double amount;
  final DateTime date;
  final String driveTitle;
  final String receiptNo;

  const DonationRecord({
    required this.id,
    required this.amount,
    required this.date,
    required this.driveTitle,
    required this.receiptNo,
  });
}
